#!/bin/sh
echo pwned
